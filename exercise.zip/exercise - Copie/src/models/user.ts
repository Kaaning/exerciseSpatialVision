export class User {
    name: string;
    email: string;
    dateOfBirth: string;
    latitude: number;
    longitude: number;
}